
/*
*   Tyler Hunt
*   Advanved C++
*   OCCC Fall 2017
*   Class code
*   Person.h
*/

#include <string>
#include "OCCCDate.h"

using namespace std;

class Person{

    private:
        string firstName;
        string lastName;
        OCCCDate dob;

    public: 
        Person();
        Person(string, string);
        Person(string firstName, string lastName, OCCCDate dob);

        string getFirstName();
        string getLastName();
        OCCCDate getDate();
        int getAgeInYears();

        void setFirstName(string);
        void setLastName(string);

        bool equals(Person);
        bool equalsIgnorecase(string, string);

        string toUpperCase(string);
        string toString();
};

