 /*
*   Tyler Hunt
*   Advanved C++
*   OCCC Fall 2017
*   Person.cpp
*/
#include <string>
#include "Person.h"
#include <iostream>

using namespace std;

Person::Person(){
    firstName = "N/A";
    lastName = "N/A";
    dob = OCCCDate();
}

Person::Person(string firstName, string lastName){
    this->firstName = firstName;
    this->lastName = lastName;
    dob = OCCCDate();
}

Person::Person(string firstName, string lastName, OCCCDate dob){
    this -> firstName = firstName;
    this -> lastName = lastName;
    this -> dob = dob;
}

string Person::getFirstName(){
    return this->firstName;
}

string Person::getLastName(){
    return this->lastName;
}

void Person::setFirstName(string fname){
    this->firstName = fname;
}

void Person::setLastName(string lName){
    this->lastName = lName;
}

OCCCDate Person::getDate(){
    return dob;
}

//getter for person's age
int Person::getAgeInYears(){
    return dob.getDifference(); 
}

//compare a person object with another person object
bool Person::equals(Person p){
    if (this ->firstName == p.firstName && this ->lastName == p.lastName){
        return true;
    }else{
        return false;
    }
}

string Person::toString(){
  return "First name: " + this->getFirstName() + " Last name: " + this->getLastName();
}

// int main(int argc, char * argv[])
// {
//     Person p1 = Person();
//     Person p2 = Person("Tyler", "Hunt");

//     //test default person constructor and toString function
//     cout << "** Person created with default constructor - Person() **" << endl;
//    // cout << p1.toString() << endl;


//     cout << "** Default OCCCDate constructor - OCCCDate() and Person.toString() functions" <<endl;
//     cout << p2.toString() << endl;

// }



